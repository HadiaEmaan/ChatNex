# 🤖 Multi-AI Hub Chatbot (Java Backend + HTML/CSS/JS Frontend)

A full-stack chatbot web application featuring an HTML5/CSS3/JavaScript frontend and a lightweight, zero-dependency Java HTTP Server backend. Supports dynamic routing between **ChatGPT (OpenAI)**, **Claude (Anthropic)**, **Gemini (Google)**, and **Perplexity**, along with interactive temperature control.

---

## 🌟 Key Features

1. **Multi-Engine AI Selector**: Switch between ChatGPT, Claude, Gemini, and Perplexity on the fly.
2. **Temperature Control Slider**: Fine-tune AI response creativity from `0.0` (focused/analytical) to `1.0` (creative/unique).
3. **Java Middleman Logic Engine**: 
   - Receives JSON requests (`model`, `temperature`, `prompt`) on `POST /api/chat`.
   - Uses `switch`/`if-else` routing logic.
   - Hides secret API keys from the client-side for security.
   - Includes automatic simulated response fallback mode if API keys are not provided.
4. **Sleek Modern Web UI**: Dark mode UI with glassmorphism, glowing accents, unique user and AI chat bubbles, typing indicator, quick prompt suggestions, and HTML escape security.

---

## 📁 Project Structure

```
multi-ai-chatbot/
├── src/
│   └── com/
│       └── example/
│           └── chatbot/
│               ├── Main.java              # Java HTTP Server entry point
│               ├── ChatRequest.java       # DTO for request payload
│               ├── ChatResponse.java      # DTO for response payload
│               ├── AIServiceRouter.java   # Router logic engine for AI APIs
│               └── JsonUtils.java         # Lightweight JSON parser & serializer
├── web/
│   └── index.html                         # Modern HTML/CSS/JS chat interface
├── pom.xml                                # Optional Maven configuration
├── build.bat                              # Windows 1-click build script
├── run.bat                                # Windows 1-click run script
└── README.md                              # Documentation
```

---

## 🚀 How to Run

### Option 1: Direct Java Command Line (Zero External Dependencies)

1. **Compile Java Files**:
   ```cmd
   javac -d bin -sourcepath src src/com/example/chatbot/Main.java
   ```

2. **Run Server**:
   ```cmd
   java -cp bin com.example.chatbot.Main
   ```

3. **Open Browser**:
   Navigate to `http://localhost:8080` in your web browser.

---

### Option 2: Windows 1-Click Batch Scripts

- Double click `build.bat` to compile the Java project.
- Double click `run.bat` to launch the server!

---

### Option 3: Maven (Optional)

```cmd
mvn clean compile exec:java
```

---

## 🔐 API Key Configuration (Optional)

To connect live API keys for real AI responses, set the corresponding environment variables before starting the server:

- **OpenAI (ChatGPT)**: `OPENAI_API_KEY=sk-...`
- **Anthropic (Claude)**: `ANTHROPIC_API_KEY=sk-ant-...`
- **Google (Gemini)**: `GEMINI_API_KEY=AIzaSy...`
- **Perplexity**: `PERPLEXITY_API_KEY=pplx-...`

If keys are not set, the Java backend safely defaults to **Simulated Mode**, demonstrating the engine routing and temperature setting without throwing errors!
