document.addEventListener('DOMContentLoaded', () => {
    initParticlesCanvas();

    // DOM Elements
    const heroView = document.getElementById('heroView');
    const messagesView = document.getElementById('messagesView');
    const userInput = document.getElementById('userInput');
    const sendBtn = document.getElementById('sendBtn');
    const micBtn = document.getElementById('micBtn');
    const modelSelect = document.getElementById('modelSelect');
    const newChatBtn = document.getElementById('newChatBtn');
    const exportBtn = document.getElementById('exportBtn');
    const clearBtn = document.getElementById('clearBtn'); // Delete All Chats button
    const settingsBtn = document.getElementById('settingsBtn');
    const settingsModal = document.getElementById('settingsModal');
    const closeModal = document.getElementById('closeModal');
    const saveSettings = document.getElementById('saveSettings');
    const tempSlider = document.getElementById('tempSlider');
    const tempValDisplay = document.getElementById('tempValDisplay');
    const systemPromptInput = document.getElementById('systemPromptInput');
    const chatHistoryList = document.getElementById('chatHistoryList');

    const openaiKeyInput = document.getElementById('openaiKeyInput');
    const anthropicKeyInput = document.getElementById('anthropicKeyInput');
    const geminiKeyInput = document.getElementById('geminiKeyInput');
    const perplexityKeyInput = document.getElementById('perplexityKeyInput');

    let currentTemperature = 0.7;
    let currentSystemPrompt = "You are a helpful AI assistant.";
    
    // Multi-session chat management
    let chats = JSON.parse(localStorage.getItem('NEURO_AI_CHATS') || '[]');
    let currentChatId = null;

    // Load saved API Keys
    if (openaiKeyInput) openaiKeyInput.value = localStorage.getItem('OPENAI_API_KEY') || '';
    if (anthropicKeyInput) anthropicKeyInput.value = localStorage.getItem('ANTHROPIC_API_KEY') || '';
    if (geminiKeyInput) geminiKeyInput.value = localStorage.getItem('GEMINI_API_KEY') || '';
    if (perplexityKeyInput) perplexityKeyInput.value = localStorage.getItem('PERPLEXITY_API_KEY') || '';

    // Render initial sidebar chat sessions
    renderChatHistory();

    // Temperature Slider Listener
    if (tempSlider) {
        tempSlider.addEventListener('input', (e) => {
            currentTemperature = parseFloat(e.target.value);
            tempValDisplay.textContent = currentTemperature.toFixed(1);
        });
    }

    // Modal Controls
    if (settingsBtn) settingsBtn.addEventListener('click', () => settingsModal.classList.add('open'));
    if (closeModal) closeModal.addEventListener('click', () => settingsModal.classList.remove('open'));
    if (saveSettings) saveSettings.addEventListener('click', () => {
        currentSystemPrompt = systemPromptInput.value.trim();
        if (openaiKeyInput) localStorage.setItem('OPENAI_API_KEY', openaiKeyInput.value.trim());
        if (anthropicKeyInput) localStorage.setItem('ANTHROPIC_API_KEY', anthropicKeyInput.value.trim());
        if (geminiKeyInput) localStorage.setItem('GEMINI_API_KEY', geminiKeyInput.value.trim());
        if (perplexityKeyInput) localStorage.setItem('PERPLEXITY_API_KEY', perplexityKeyInput.value.trim());

        showToast("Settings saved!");
        settingsModal.classList.remove('open');
    });

    // Close any open 3-dots dropdown when clicking outside
    document.addEventListener('click', (e) => {
        if (!e.target.closest('.chat-item-wrapper')) {
            document.querySelectorAll('.chat-dropdown-menu').forEach(m => m.classList.remove('show'));
        }
    });

    // Auto-expand textarea
    userInput.addEventListener('input', () => {
        userInput.style.height = 'auto';
        userInput.style.height = Math.min(userInput.scrollHeight, 120) + 'px';
    });

    // Keydown listener
    userInput.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            handleSend();
        }
    });

    sendBtn.addEventListener('click', handleSend);

    // + New Chat Action
    newChatBtn.addEventListener('click', startNewChat);

    function startNewChat() {
        currentChatId = null;
        messagesView.innerHTML = '';
        messagesView.style.display = 'none';
        heroView.style.display = 'flex';
        userInput.value = '';
        document.querySelectorAll('.chat-item-wrapper').forEach(el => el.classList.remove('active'));
    }

    // Delete All Chats Action
    clearBtn.addEventListener('click', () => {
        if (chats.length === 0) {
            showToast("No chat history to delete!");
            return;
        }
        if (confirm("Are you sure you want to delete ALL chat conversations?")) {
            chats = [];
            localStorage.removeItem('NEURO_AI_CHATS');
            startNewChat();
            renderChatHistory();
            showToast("All chats deleted!");
        }
    });

    // Export Active Chat Action
    exportBtn.addEventListener('click', () => {
        const activeChat = chats.find(c => c.id === currentChatId);
        if (!activeChat || activeChat.messages.length === 0) {
            showToast("No active chat history to export!");
            return;
        }
        let content = `=== Neuro AI Chat Transcript: ${activeChat.title} ===\n\n`;
        activeChat.messages.forEach(msg => {
            content += `[${msg.sender.toUpperCase()} - ${msg.time}]\n${msg.text}\n\n`;
        });
        const blob = new Blob([content], { type: 'text/plain' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `neuro_ai_${activeChat.title.replace(/[^a-zA-Z0-9]/g, '_')}.txt`;
        a.click();
        URL.revokeObjectURL(url);
    });

    // Voice Speech Recognition
    if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
        const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
        const recognition = new SpeechRecognition();
        recognition.continuous = false;
        recognition.interimResults = false;

        micBtn.addEventListener('click', () => {
            if (micBtn.classList.contains('recording')) {
                recognition.stop();
            } else {
                recognition.start();
                micBtn.classList.add('recording');
            }
        });

        recognition.onresult = (event) => {
            const transcript = event.results[0][0].transcript;
            userInput.value = transcript;
            micBtn.classList.remove('recording');
        };

        recognition.onerror = () => micBtn.classList.remove('recording');
        recognition.onend = () => micBtn.classList.remove('recording');
    } else {
        micBtn.style.opacity = '0.4';
        micBtn.title = 'Speech recognition not supported in this browser.';
    }

    // Main Send Handler
    async function handleSend() {
        const text = userInput.value.trim();
        if (!text) return;

        // Ensure active chat session
        if (!currentChatId) {
            currentChatId = 'chat_' + Date.now();
            const newChat = {
                id: currentChatId,
                title: text.length > 25 ? text.substring(0, 25) + '...' : text,
                messages: [],
                createdAt: new Date().toISOString()
            };
            chats.unshift(newChat);
        }

        const activeChat = chats.find(c => c.id === currentChatId);

        // Hide Hero, Show Messages View
        heroView.style.display = 'none';
        messagesView.style.display = 'flex';

        // 1. Add User Message
        const timeStr = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
        appendUserMessage(text, timeStr);
        activeChat.messages.push({ sender: 'user', text: text, time: timeStr });
        saveChatsToStorage();

        userInput.value = '';
        userInput.style.height = '24px';
        setLoading(true);

        const selectedModel = modelSelect.value;
        const modelName = modelSelect.options[modelSelect.selectedIndex].text;

        // 2. Append AI Thinking Row
        const aiRow = createAiMessageRow(modelName);
        const bubble = aiRow.querySelector('.msg-bubble');
        bubble.innerHTML = `<span style="color: var(--text-muted);">Thinking...</span>`;

        try {
            const response = await fetch('/api/chat', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    model: selectedModel,
                    temperature: currentTemperature,
                    prompt: text,
                    system_prompt: currentSystemPrompt,
                    api_keys: {
                        chatgpt: localStorage.getItem('OPENAI_API_KEY') || '',
                        claude: localStorage.getItem('ANTHROPIC_API_KEY') || '',
                        gemini: localStorage.getItem('GEMINI_API_KEY') || '',
                        perplexity: localStorage.getItem('PERPLEXITY_API_KEY') || ''
                    }
                })
            });

            if (!response.ok) throw new Error(`HTTP ${response.status}`);
            const data = await response.json();

            const aiTime = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
            bubble.innerHTML = formatMarkdown(data.response);
            activeChat.messages.push({ sender: 'ai', text: data.response, time: aiTime, model: modelName });
            saveChatsToStorage();

        } catch (err) {
            bubble.innerHTML = `<span style="color: #ef4444;">⚠️ Error: ${escapeHtml(err.message)}</span>`;
        } finally {
            setLoading(false);
            messagesView.scrollTop = messagesView.scrollHeight;
            renderChatHistory();
        }
    }

    function appendUserMessage(text, timeStr) {
        const row = document.createElement('div');
        row.className = 'msg-row user-msg';
        row.innerHTML = `
            <div class="msg-header">You • ${timeStr}</div>
            <div class="msg-bubble">${escapeHtml(text)}</div>
        `;
        messagesView.appendChild(row);
        messagesView.scrollTop = messagesView.scrollHeight;
    }

    function createAiMessageRow(modelName) {
        const row = document.createElement('div');
        row.className = 'msg-row ai-msg';
        row.innerHTML = `
            <div class="msg-header">🤖 ${escapeHtml(modelName)}</div>
            <div class="msg-bubble"></div>
        `;
        messagesView.appendChild(row);
        return row;
    }

    // Render Sidebar History Items with 3-Dots Menu
    function renderChatHistory() {
        chatHistoryList.innerHTML = '';
        chats.forEach(chat => {
            const wrapper = document.createElement('div');
            wrapper.className = `chat-item-wrapper ${chat.id === currentChatId ? 'active' : ''}`;
            wrapper.dataset.id = chat.id;

            wrapper.innerHTML = `
                <span class="chat-item-title">${escapeHtml(chat.title)}</span>
                <div class="chat-item-dots" title="Options">⋮</div>
                <div class="chat-dropdown-menu">
                    <div class="dropdown-option share-opt">📤 Share Chat</div>
                    <div class="dropdown-option delete-opt">🗑️ Delete Chat</div>
                </div>
            `;

            // Click wrapper to load chat
            wrapper.addEventListener('click', (e) => {
                if (e.target.closest('.chat-item-dots') || e.target.closest('.chat-dropdown-menu')) return;
                loadChatSession(chat.id);
            });

            // Click 3 dots to toggle dropdown
            const dotsBtn = wrapper.querySelector('.chat-item-dots');
            const dropdown = wrapper.querySelector('.chat-dropdown-menu');

            dotsBtn.addEventListener('click', (e) => {
                e.stopPropagation();
                document.querySelectorAll('.chat-dropdown-menu').forEach(m => {
                    if (m !== dropdown) m.classList.remove('show');
                });
                dropdown.classList.toggle('show');
            });

            // Share Chat Option
            const shareOpt = wrapper.querySelector('.share-opt');
            shareOpt.addEventListener('click', (e) => {
                e.stopPropagation();
                dropdown.classList.remove('show');
                shareChatSession(chat);
            });

            // Delete Specific Chat Option
            const deleteOpt = wrapper.querySelector('.delete-opt');
            deleteOpt.addEventListener('click', (e) => {
                e.stopPropagation();
                dropdown.classList.remove('show');
                deleteSingleChatSession(chat.id);
            });

            chatHistoryList.appendChild(wrapper);
        });
    }

    function loadChatSession(id) {
        currentChatId = id;
        const targetChat = chats.find(c => c.id === id);
        if (!targetChat) return;

        heroView.style.display = 'none';
        messagesView.style.display = 'flex';
        messagesView.innerHTML = '';

        targetChat.messages.forEach(msg => {
            if (msg.sender === 'user') {
                appendUserMessage(msg.text, msg.time || '');
            } else {
                const row = createAiMessageRow(msg.model || 'AI Assistant');
                row.querySelector('.msg-bubble').innerHTML = formatMarkdown(msg.text);
            }
        });

        messagesView.scrollTop = messagesView.scrollHeight;
        renderChatHistory();
    }

    function deleteSingleChatSession(id) {
        chats = chats.filter(c => c.id !== id);
        saveChatsToStorage();

        if (currentChatId === id) {
            startNewChat();
        }
        renderChatHistory();
        showToast("Chat session deleted!");
    }

    function shareChatSession(chat) {
        if (!chat || !chat.messages.length) {
            showToast("No message history to share!");
            return;
        }
        let transcript = `=== Shared Chat: ${chat.title} ===\n\n`;
        chat.messages.forEach(m => {
            transcript += `[${m.sender.toUpperCase()}]: ${m.text}\n\n`;
        });
        
        navigator.clipboard.writeText(transcript).then(() => {
            showToast("📋 Chat copied to clipboard!");
        }).catch(() => {
            showToast("Failed to copy transcript.");
        });
    }

    function saveChatsToStorage() {
        localStorage.setItem('NEURO_AI_CHATS', JSON.stringify(chats));
    }

    function showToast(text) {
        const existing = document.querySelector('.toast-msg');
        if (existing) existing.remove();

        const toast = document.createElement('div');
        toast.className = 'toast-msg';
        toast.textContent = text;
        document.body.appendChild(toast);

        setTimeout(() => toast.remove(), 2500);
    }

    function setLoading(isLoading) {
        userInput.disabled = isLoading;
        sendBtn.disabled = isLoading;
    }

    function escapeHtml(str) {
        return String(str).replace(/[&<>"']/g, s => ({
            '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
        }[s]));
    }

    function formatMarkdown(text) {
        if (!text) return '';
        let html = escapeHtml(text);
        html = html.replace(/```([\s\S]*?)```/g, '<pre><code>$1</code></pre>');
        html = html.replace(/`([^`]+)`/g, '<code>$1</code>');
        html = html.replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>');
        html = html.replace(/\*([^*]+)\*/g, '<em>$1</em>');
        html = html.replace(/\n/g, '<br>');
        return html;
    }

    window.selectPrompt = function(promptText) {
        userInput.value = promptText;
        handleSend();
    };
});

// Interactive Particle Constellation Background
function initParticlesCanvas() {
    const canvas = document.getElementById('particlesCanvas');
    if (!canvas) return;
    const ctx = canvas.getContext('2d');

    let width = canvas.width = window.innerWidth;
    let height = canvas.height = window.innerHeight;

    window.addEventListener('resize', () => {
        width = canvas.width = window.innerWidth;
        height = canvas.height = window.innerHeight;
    });

    const numParticles = 60;
    const particles = [];

    for (let i = 0; i < numParticles; i++) {
        particles.push({
            x: Math.random() * width,
            y: Math.random() * height,
            vx: (Math.random() - 0.5) * 0.6,
            vy: (Math.random() - 0.5) * 0.6,
            radius: Math.random() * 2 + 1
        });
    }

    function animate() {
        ctx.clearRect(0, 0, width, height);

        for (let i = 0; i < numParticles; i++) {
            let p = particles[i];
            p.x += p.vx;
            p.y += p.vy;

            if (p.x < 0 || p.x > width) p.vx *= -1;
            if (p.y < 0 || p.y > height) p.vy *= -1;

            ctx.beginPath();
            ctx.arc(p.x, p.y, p.radius, 0, Math.PI * 2);
            ctx.fillStyle = 'rgba(0, 210, 255, 0.4)';
            ctx.fill();

            for (let j = i + 1; j < numParticles; j++) {
                let p2 = particles[j];
                let dist = Math.hypot(p.x - p2.x, p.y - p2.y);
                if (dist < 130) {
                    ctx.beginPath();
                    ctx.moveTo(p.x, p.y);
                    ctx.lineTo(p2.x, p2.y);
                    ctx.strokeStyle = `rgba(0, 194, 255, ${0.25 * (1 - dist / 130)})`;
                    ctx.lineWidth = 0.8;
                    ctx.stroke();
                }
            }
        }
        requestAnimationFrame(animate);
    }
    animate();
}
